﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ordersystem
{
    public partial class 点餐 : Form
    {
        string connString = Properties.Settings.Default.ordersystemConnectionString;
        DataSet dingdanset = new DataSet();
        int dingdanid;

        public 点餐()
        {
            InitializeComponent();

            SqlConnection conn = new SqlConnection(connString);
            //加载菜单
            SqlDataAdapter adapter = new SqlDataAdapter("select 菜名 from 菜单", conn);
            //创建订单
            SqlCommand cmd = new SqlCommand("insert into 订单 (合计,日期) values (NULL,NULL);select @@IDENTITY", conn);

            conn.Open();
            dingdanid = Convert.ToInt32(cmd.ExecuteScalar());
            adapter.Fill(dingdanset);
            conn.Close();

            comboBox1.DataSource = dingdanset.Tables[0];
            comboBox1.DisplayMember = "菜名";
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void 取消_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(connString);
            SqlCommand cmd = new SqlCommand("delete from 订单 where Id = '"+dingdanid+"'", conn);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();

            this.Hide();
            this.Owner.Show();
        }

        private void 添加_Click(object sender, EventArgs e)
        {
            int num = (int)numericUpDown1.Value;
            string caiming = comboBox1.Text;
            if (num > 0)
            {
                SqlConnection conn = new SqlConnection(connString);
                SqlCommand findcaiid = new SqlCommand("select id from 菜单 where 菜名 = N'" + comboBox1.Text + "'", conn);
                conn.Open();
                int caiid = Convert.ToInt32(findcaiid.ExecuteScalar());
                SqlCommand cmd = new SqlCommand("insert into 订单项 (菜品id,数量,订单id) values (" + caiid + "," + num + "," + dingdanid + ")", conn);
                if (cmd.ExecuteNonQuery() == 1)
                {
                    MessageBox.Show(comboBox1.Text + "add succeed");
                }
                conn.Close();
            }
            else
            {
                MessageBox.Show("数量不能为0");
            }
        }

        private void 提交_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(connString);
            SqlCommand cmd = new SqlCommand("select * from 订单项 where 订单id = '"+dingdanid+"'", conn);

            conn.Open();
            SqlDataReader r = cmd.ExecuteReader();
            if (r.Read())
            {
                订单确认 w1 = new 订单确认(dingdanid);
                w1.Owner = this;
                this.Hide();
                w1.Show();
            }
            else
            {
                MessageBox.Show("你还没添加菜品呢");
            }
            conn.Close();
        }
    }
}
