﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ordersystem
{
    public partial class 订单确认 : Form
    {
        int dingdanid;
        int total = 0;
        string connString = Properties.Settings.Default.ordersystemConnectionString;
        DataSet dingdanset = new DataSet();

        public 订单确认(int dingdanhao)
        {
            InitializeComponent();
            dingdanid = dingdanhao;

            SqlConnection conn = new SqlConnection(connString);
            //SqlDataAdapter adapter = new SqlDataAdapter("select 菜品id,数量 from 订单项 where 订单id = '"+ dingdanid +"'", conn);
            SqlCommand cmd = new SqlCommand("select 菜品id,数量 from 订单项 where 订单id = '"+ dingdanid +"'", conn);

            
            int caiid;
            int cainum;
            int caiprice;
            int totalprice;
            string caiming;
            
            listView1.BeginUpdate();
            listView1.Columns.Add("菜名");
            listView1.Columns.Add("单价");
            listView1.Columns.Add("数量");
            listView1.Columns.Add("合计");
            listView1.View = View.Details;

            conn.Open();
            SqlDataReader r = cmd.ExecuteReader();
            while (r.Read())
            {
                caiid = Convert.ToInt32(r[0]);
                cainum = Convert.ToInt32(r[1]);

                SqlConnection conn2 = new SqlConnection(connString);
                SqlCommand cmd1 = new SqlCommand("select 菜名 from 菜单 where Id = '" + caiid + "'", conn2);
                SqlCommand cmd2 = new SqlCommand("select 价格 from 菜单 where Id = '" + caiid + "'", conn2);
                conn2.Open();
                caiming = Convert.ToString(cmd1.ExecuteScalar());
                caiprice = Convert.ToInt32(cmd2.ExecuteScalar());
                conn2.Close();
                totalprice = caiprice * cainum;
                total += totalprice;
                ListViewItem lvi = new ListViewItem();
                lvi.Text = caiming;
                lvi.SubItems.Add(caiprice+"");
                lvi.SubItems.Add(cainum+"");
                lvi.SubItems.Add(totalprice+"");
                listView1.Items.Add(lvi);

            }
            listView1.EndUpdate();
            r.Close();
            总计Box.Text = Convert.ToString(total);

        }

        private void label2_Click(object sender, EventArgs e)
        {
            if (total > 0)
            {
                SqlConnection conn = new SqlConnection(connString);
                string date = DateTime.Now.ToString("yyyy/MM/dd");
                SqlCommand cmd = new SqlCommand("insert into 营业额 (日期,金额,订单id) values ('"+ date + "','" + total + "','"+ dingdanid + "')", conn);
                conn.Open();
                if (cmd.ExecuteNonQuery() == 1)
                {
                    MessageBox.Show("下单成功,一共消费" + total + "元," + DateTime.Now);
                    this.Hide();
                    this.Owner.Owner.Show();
                }
                conn.Close();
            }
            else
            {
                this.Hide();
                this.Owner.Show();
            }
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

            this.Hide();
            this.Owner.Show();
        }
    }
}
