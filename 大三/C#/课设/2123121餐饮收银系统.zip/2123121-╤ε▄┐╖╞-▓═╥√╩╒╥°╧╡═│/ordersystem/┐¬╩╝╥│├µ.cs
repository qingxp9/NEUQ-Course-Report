﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ordersystem
{
    public partial class 开始页面 : Form
    {
        public 开始页面()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            点餐 w1 = new 点餐();
            w1.Owner = this;
            this.Hide();
            w1.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            统计 t1 = new 统计();
            t1.Owner = this;
            this.Hide();
            t1.Show();
        }
    }
}
