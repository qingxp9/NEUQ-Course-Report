﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ordersystem
{
    public partial class 统计 : Form
    {
        string connString = Properties.Settings.Default.ordersystemConnectionString;

        public 统计()
        {
            InitializeComponent();

            autoshow(DateTime.Now.ToString("yyyy/MM/dd"));
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            this.Owner.Show();
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            autoshow(dateTimePicker1.Value.ToString("yyyy/MM/dd"));

        }

        private void autoshow(string date)
        {
            //总计
            SqlConnection conn = new SqlConnection(connString);
            SqlCommand cmd = new SqlCommand("select sum(金额) from 营业额 where 日期 = '" + date + "'", conn);
            conn.Open();
            总计Box.Text = Convert.ToString(cmd.ExecuteScalar());
            conn.Close();

            //列表
            listView1.BeginUpdate();
            listView1.Columns.Add("订单id");
            listView1.Columns.Add("金额");
            listView1.View = View.Details;

            SqlCommand cmd2 = new SqlCommand("select 订单id,金额 from 营业额 where 日期 = '" + date + "'", conn);
            conn.Open();
            SqlDataReader r = cmd2.ExecuteReader();
            while (r.Read())
            {
                int dingdanid = Convert.ToInt32(r[0]);
                int jinge = Convert.ToInt32(r[1]);

                ListViewItem lvi = new ListViewItem();
                lvi.Text = dingdanid.ToString();
                lvi.SubItems.Add(jinge.ToString());
                listView1.Items.Add(lvi);

            }
            r.Close();
            listView1.EndUpdate();
        }
    }
}
